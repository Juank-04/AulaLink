package com.example.aulalink.data.models

data class Curso(
    val id: String,
    val nombre: String,
    val descripcion: String
)
