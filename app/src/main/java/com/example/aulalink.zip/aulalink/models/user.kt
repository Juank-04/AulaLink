package com.example.aulalink.data.models

data class UserProfile(
    val email: String,
    val role: String // "tutor" o "estudiante"
)
