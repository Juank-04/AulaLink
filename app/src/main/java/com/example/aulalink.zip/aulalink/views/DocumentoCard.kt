package com.example.aulalink.views

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.aulalink.data.models.UserProfile

@Composable
fun AuthScreen(
    onLoginSuccess: (UserProfile) -> Unit
) {
    var email by remember { mutableStateOf("") }
    var isTutor by remember { mutableStateOf(false) }
    var isRegister by remember { mutableStateOf(false) }  // Alternancia login/registro

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = if (isRegister) "Registro" else "Iniciar sesión",
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(bottom = 16.dp)
        )
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Correo electrónico") },
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row {
            Checkbox(
                checked = isTutor,
                onCheckedChange = { isTutor = it }
            )
            Text("Ingresar como tutor")
        }
        Spacer(modifier = Modifier.height(6.dp))
        TextButton(
            onClick = { isRegister = !isRegister }
        ) {
            Text(if (isRegister) "¿Ya tienes cuenta? Inicia sesión" else "¿No tienes cuenta? Regístrate")
        }
        Spacer(modifier = Modifier.height(10.dp))
        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                onLoginSuccess(
                    UserProfile(
                        email = email.ifBlank { "tutor@aula.com" },
                        role = if (isTutor) "tutor" else "estudiante"
                    )
                )
            },
            enabled = email.isNotBlank()
        ) {
            Text(if (isRegister) "Registrarse" else "Ingresar")
        }
    }
}
