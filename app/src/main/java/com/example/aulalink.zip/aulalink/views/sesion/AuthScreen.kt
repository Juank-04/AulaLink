package com.example.aulalink.views.sesion

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.aulalink.data.models.UserProfile
import com.example.aulalink.views.LoginView
import com.example.aulalink.views.RegisterView


@Composable
fun AuthScreen(
    onAuthSuccess: (UserProfile) -> Unit = {}
) {
    var isLogin by remember { mutableStateOf(true) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        if (isLogin) {
            LoginView(
                onLoginSuccess = { userProfile -> onAuthSuccess(userProfile) },
                onSwitchToRegister = { isLogin = false }
            )
        } else {
            RegisterView(
                onRegisterSuccess = { userProfile ->
                    isLogin = true
                    onAuthSuccess(userProfile)
                },
                onSwitchToLogin = { isLogin = true }
            )
        }
    }
}
