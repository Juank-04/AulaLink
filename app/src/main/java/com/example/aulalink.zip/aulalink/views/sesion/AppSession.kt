package com.example.aulalink.views.sesion

import com.example.aulalink.views.UserProfile

object AppSession {
    var currentUser: UserProfile? = null
}
